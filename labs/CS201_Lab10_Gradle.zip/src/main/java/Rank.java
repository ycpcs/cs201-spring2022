public enum Rank {
	// TODO - add rank values
}
