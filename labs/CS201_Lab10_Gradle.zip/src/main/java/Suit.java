public enum Suit {
	// TODO - add suit values
}
