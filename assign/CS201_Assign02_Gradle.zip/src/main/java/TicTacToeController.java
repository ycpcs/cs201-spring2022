import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * An instance of the TicTacToeController class represents
 * a controller to update the state of a tic-tac-toe game
 */
public class TicTacToeController {
	public static final String PATH = "CS201_Assign02_Gradle/";
	public static final String saveGame = "saveGame.txt";
	/**
	 * Check if the current attempted move is legal and
	 * if so, place the current player's piece.
	 * A move is legal if the row and column are both in the
	 * range 0-2, the board is currently empty at that cell,
	 * and it is the player's turn.
	 *
	 * @param model the current game model
	 * @param player the player attempting to place a marker
	 * @param row the row index where the marker is being placed
	 * @param col the column index where the marker is being placed
	 * @return true if the move is legal, false if it is not
	 */
	public boolean makeMove(TicTacToeModel model, int player, int row, int col) {
		throw new UnsupportedOperationException("not implemented yet");
	}
	
	/**
	 * Check if the current move results in a winning
	 * configuration. A winning configuration has three
	 * consecutive markers for the current player
	 * either in a row, column, or diagonal on the board
	 *
	 * @param model the current game model
	 * @return true if the current player wins, false if not
	 */
	public boolean checkWin(TicTacToeModel model){
		throw new UnsupportedOperationException("not implemented yet");
	}
	
	/**
	 * Check if the current move results in a draw
	 * configuration. A game is a draw if all the
	 * cells are non-empty.
	 * It is assumed that this method will only be
	 * called after the win condition is checked.
	 *
	 * @param model the current game model
	 * @return true if there is a draw, false if not
	 */
	public boolean checkDraw(TicTacToeModel model) {
		throw new UnsupportedOperationException("not implemented yet");
	}

	/**
	 * Switch the current player's turn.
	 *
	 * @param model the current game model
	 */
	public void changePlayer(TicTacToeModel model) {
		throw new UnsupportedOperationException("not implemented yet");
	}

	/**
	 * Read a game state from the saveGame file and create a new model.
	 *
	 * @return TicTacToeModel if loading is successful, null if not
	 */
	public TicTacToeModel loadGame() {
		throw new UnsupportedOperationException("not implemented yet");
	}

	/**
	 * Write the game state to the saveGame file.
	 *
	 * @return true if loading is successful, false if not
	 */
	public boolean saveGame(TicTacToeModel model) {
		throw new UnsupportedOperationException("not implemented yet");
	}

}
